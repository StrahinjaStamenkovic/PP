package AST;

public abstract class Statement extends ASTNode{

}
