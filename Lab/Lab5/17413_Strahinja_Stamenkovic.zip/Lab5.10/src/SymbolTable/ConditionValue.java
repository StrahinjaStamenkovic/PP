package SymbolTable;

public class ConditionValue {
	public boolean active;
	public boolean value;
	public ConditionValue( boolean isActive, boolean val )
	{
		active = isActive;
		value = val;
	}
}
